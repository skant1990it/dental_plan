<?php
return array(
    'Stripe\Customer' => __DIR__ . '/src/StripeModule/stripephp340/init.php',
    'Stripe\Stripe' => __DIR__ . '/src/StripeModule/stripephp340/init.php',
    'Stripe\Plan' => __DIR__ . '/src/StripeModule/stripephp340/init.php',
);


